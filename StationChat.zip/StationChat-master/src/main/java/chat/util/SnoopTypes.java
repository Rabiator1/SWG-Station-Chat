package chat.util;

public class SnoopTypes {
	
	public static final byte SNOOP_INSTANTMESSAGE = 0;
	public static final byte SNOOP_ROOMMESSAGE = 1;
	public static final byte SNOOP_PERSISTENTMESSAGE = 2;
	public static final byte SNOOP_END = 3;

}
