# StationChat

A ChatAPI server emulator for Daybreak(formerly Sony Online Entertainment) games. 
Uses TCP to connect to the game's cluster ChatAPI Client.

Currently unfinished and not tested in production. Use at your own risk, the creator(s) of this software are not responsible for any copyright infringement by the users.
